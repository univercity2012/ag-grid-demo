

Running The Project
=

1. Install NPM dependencies:
```npm install```

2. Build using webpack
```./node_modules/.bin/webpack```

3. Run the web server
```node start.js```

Then browse to http://<ip>:8080/
