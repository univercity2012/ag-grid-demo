var agGrid = require('ag-grid');
require('ag-grid-enterprise');
require('ag-grid/dist/styles/ag-grid.css');
require('ag-grid/dist/styles/theme-fresh.css');


(function() {

    var columnDefs = [
        {
            headerName: 'Dimensions',
            children: [
                {headerName: "Bond Type", field: "bond_type", enableRowGroup: true},
                {headerName: "Query Date", field: "query_date", enableRowGroup: true, filter: 'number'},
                {headerName: "Maturity Date", field: "maturity_date", enableRowGroup: true},
                {headerName: "Base Currency", field: "base_currency", enableRowGroup: true},
                {headerName: "Reporting Currency", field: "reporting_currency", enableRowGroup: true},
                {headerName: "Repos", field: "repos", enableRowGroup: true},
                {headerName: "Guarantees Received", field: "guarantees_received", enableRowGroup: true},
                {headerName: "Banking Sector", field: "banking_sector", enableRowGroup: true},
                {headerName: "Securities Held", field: "securities_held", enableRowGroup: true},
                {headerName: "Pension Funds", field: "pension_funds", enableRowGroup: true},
                {headerName: "Investment Funds", field: "investment_funds", enableRowGroup: true},
                {headerName: "Insurance Surety Companies", field: "insurance_surety_companies", enableRowGroup: true},
                {headerName: "Residents", field: "residents", enableRowGroup: true},
                {headerName: "Other Residents", field: "other_residents", enableRowGroup: true},
                {headerName: "Non Residents", field: "non_residents", enableRowGroup: true},
                {headerName: "Total Outstanding", field: "total_outstanding", enableRowGroup: true}
            ]
        },
        {
            headerName: 'Values',
            children: [
                {headerName: "Repos", field: "repos", enableValue: true, aggFunc: 'sum', minimumFractionDigits: 2},
                {headerName: "Guarantees Received", field: "guarantees_received", enableValue: true, aggFunc: 'sum', minimumFractionDigits: 2},
                {headerName: "Banking Sector", field: "banking_sector", enableValue: true, aggFunc: 'sum', minimumFractionDigits: 2},
                {headerName: "Securities Held", field: "securities_held", enableValue: true, aggFunc: 'sum', minimumFractionDigits: 2},
                {headerName: "Pension Funds", field: "pension_funds", enableValue: true, aggFunc: 'sum', minimumFractionDigits: 2},
                {headerName: "Investment Funds", field: "investment_funds", enableValue: true, aggFunc: 'sum', minimumFractionDigits: 2},
                {headerName: "Insurance Surety Companies", field: "insurance_surety_companies", enableValue: true, aggFunc: 'sum', minimumFractionDigits: 2},
                {headerName: "Residents", field: "residents", enableValue: true, aggFunc: 'sum', minimumFractionDigits: 2},
                {headerName: "Other Residents", field: "other_residents", enableValue: true, aggFunc: 'sum', minimumFractionDigits: 2},
                {headerName: "Non Residents", field: "non_residents", enableValue: true, aggFunc: 'sum', minimumFractionDigits: 2},
                {headerName: "Total Outstanding", field: "total_outstanding", enableValue: true, aggFunc: 'sum', minimumFractionDigits: 2}
            ]
        }
    ];
    
    var gridOptions = {
        defaultColDef: {
            filter: 'text',
            filterParams: {
                newRowsAction: 'keep'
            },
            allowedAggFuncs: ['sum','min','max']
        },
        columnDefs: columnDefs,
        enableColResize: true,
        rowModelType: 'enterprise',
        rowGroupPanelShow: 'always',
        animateRows: true,
        showToolPanel: true,
        enableSorting: true,
        suppressDragLeaveHidesColumns: true,
        debug: true,
        onGridReady: function(params) {
            // params.api.sizeColumnsToFit();
        }
    };

    function currencyFormatter(params) {
        return '£' + formatNumber(params.value);
    }
    
    function formatNumber(number) {
        // this puts commas into the number eg 1000 goes to 1,000,
        // i pulled this from stack overflow, i have no idea how it works
        return Math.floor(number).toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
    }
    function EnterpriseDatasource() {}

    EnterpriseDatasource.prototype.getRows = function(params) {
        console.log('EnterpriseDatasource.getRows: params = ', params);

        var requestForServer = JSON.stringify(params.request);

        var httpRequest = new XMLHttpRequest();
        httpRequest.open('POST', './mxDebtAnalysis/');
        httpRequest.setRequestHeader("Content-type", "application/json");
        httpRequest.send(requestForServer);
        httpRequest.onreadystatechange = function() {
            if (httpRequest.readyState == 4 && httpRequest.status == 200) {
                var httpResponse = JSON.parse(httpRequest.responseText);
                params.successCallback(httpResponse.rows, httpResponse.lastRow);
            }
        };
    };

    // setup the grid after the page has finished loading
    document.addEventListener('DOMContentLoaded', function() {
        var gridDiv = document.querySelector('#myGrid');
        new agGrid.Grid(gridDiv, gridOptions);

        var datasource = new EnterpriseDatasource();
        gridOptions.api.setEnterpriseDatasource(datasource);
    });
    


})();