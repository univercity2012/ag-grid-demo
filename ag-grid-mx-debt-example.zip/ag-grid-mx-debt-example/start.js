var express = require('express');
var bodyParser = require("body-parser");

var app = express();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

var mxDebtAnalysis = require('./src/server/mxDebtAnalysis');

app.post('/mxDebtAnalysis', function (req, res) {
    mxDebtAnalysis.list(req.body, function(rows, lastRow) {
        res.json({
            rows: rows,
            lastRow: lastRow
        });
    });
});

app.use(express.static('public'));

app.listen(8080, '0.0.0.0', function () {
    console.log('Example app listening on port 8080, IP 0.0.0.0!')
});
